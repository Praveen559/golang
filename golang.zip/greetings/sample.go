package main

import "fmt"

func (main)  {

	const num  = 9

	fmt.print(num)	
	
}