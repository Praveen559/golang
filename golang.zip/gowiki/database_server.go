package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"time"

	_ "github.com/go-sql-driver/mysql"
)

// {
// 	"name": "kukatpally",
// 	"place": "kukatpally",
// 	"country" : "india",
// 	"dob": "2018-09-22T12:42:31Z"
// }

func handlerget(w http.ResponseWriter, r *http.Request) {

	//database
	db, err := sql.Open("mysql", "root:test@tcp(127.0.0.1:3306)/user?parseTime=true")

	// if there is an error opening the connection, handle it
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()
	fmt.Println("connection acquired")

	//sqlStatement := `select EMAIL,PASSWORD from weaver.user where EMAIL ="$1" and PASSWORD ="$2";`
	//row := db.QueryRow(sqlStatement, u.Email, u.Pass)
	//varselect, err := db.Query(`SELECT FROM user where NAME = "$1";`)
	//var us User

	Name := r.URL.Query().Get("name")
	// sqlStatement := `SELECT NAME,PLACE,COUNTRY,DOB FROM user WHERE NAME=$1`
	// row := db.QueryRow(sqlStatement, Name)
	// if err := row.Scan(&us.Name, &us.Place, &us.Country, &us.Dob); err != nil {
	// 	log.Println(us.Name, us.Place, us.Country, us.Dob)
	// 	w.WriteHeader(http.StatusOK)
	// 	if err := json.NewEncoder(w).Encode(&us); err != nil {
	// 		panic(err)
	// 	}

	// } else {
	// 	panic(err)
	// }
	//sqlStatement := `SELECT NAME,PLACE,COUNTRY,DOB FROM user WHERE NAME=$1`
	//rows := db.QueryRow(sqlStatement, Name)
	rows, err := db.Query("SELECT NAME,PLACE,COUNTRY,DOB FROM user WHERE NAME = '" + Name + "';")
	if err != nil {
		panic(err)
	}
	// if there is an error selecting, handle it
	// be careful deferring Queries if you are using transactions
	defer db.Close()
	for rows.Next() {
		us := User{}
		err = rows.Scan(&us.Name, &us.Place, &us.Country, &us.Dob)
		w.WriteHeader(http.StatusOK)
		if err := json.NewEncoder(w).Encode(&us); err != nil {
			panic(err)
		}
		if err != nil {
			panic(err)
		}
		fmt.Println(us)
	}
	err = rows.Err()
	if err != nil {
		panic(err)
	}
	//fmt.Fprintf(w, "success")

	// user := User{}
	// err := json.NewDecoder(r.Body).Decode(&user)
	// if err != nil {
	// 	http.Error(w, err.Error(), http.StatusBadRequest)
	// 	return
	// }
}

func handlerpost(w http.ResponseWriter, r *http.Request) {
	user := User{}
	err := json.NewDecoder(r.Body).Decode(&user)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	db, err := sql.Open("mysql", "root:test@tcp(127.0.0.1:3306)/user")

	// if there is an error opening the connection, handle it
	if err != nil {
		panic(err.Error())
	}
	defer db.Close()
	insert, err := db.Query("INSERT INTO user (name,DOB,place,country) VALUES ('" + user.Name + "','" + user.Dob.Format("2006-01-02 15:04:05") + "','" + user.Place + "','" + user.Country + "');")
	// if there is an error inserting, handle it

	if err != nil {
		panic(err.Error())
	}
	// be careful deferring Queries if you are using transactions
	defer insert.Close()
	fmt.Fprintf(w, "Inserted")
}

type User struct {
	Name    string    `json:"name"`
	Place   string    `json:"place"`
	Country string    `json:"country"`
	Dob     time.Time `json:"dob"`
}

func main() {
	http.HandleFunc("/", handlerpost)
	http.HandleFunc("/get", handlerget)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
